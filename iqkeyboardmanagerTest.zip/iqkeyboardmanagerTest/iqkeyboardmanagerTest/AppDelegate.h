//
//  AppDelegate.h
//  iqkeyboardmanagerTest
//
//  Created by jession on 14-6-2.
//  Copyright (c) 2014年 we-win. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
